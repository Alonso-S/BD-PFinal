package vista;

import controlador.MenuFuncionalidades;

public class MenuPrincipal {
    public static void main(String[] args) {
        
        MenuFuncionalidades menuFuncionalidades = new MenuFuncionalidades();
        menuFuncionalidades.menuUsuario();
    }
}
