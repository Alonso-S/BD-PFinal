package modelo;

public class Fase2 {


    private int codigo;
    private String equipo1;
    private String equipo2;
    private int resultadoEquipo1;
    private int resultadoEquipo2;
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getEquipo1() {
		return equipo1;
	}
	public void setEquipo1(String equipo1) {
		this.equipo1 = equipo1;
	}
	public String getEquipo2() {
		return equipo2;
	}
	public void setEquipo2(String equipo2) {
		this.equipo2 = equipo2;
	}
	public int getResultadoEquipo1() {
		return resultadoEquipo1;
	}
	public void setResultadoEquipo1(int resultadoEquipo1) {
		this.resultadoEquipo1 = resultadoEquipo1;
	}
	public int getResultadoEquipo2() {
		return resultadoEquipo2;
	}
	public void setResultadoEquipo2(int resultadoEquipo2) {
		this.resultadoEquipo2 = resultadoEquipo2;
	}

	
}
