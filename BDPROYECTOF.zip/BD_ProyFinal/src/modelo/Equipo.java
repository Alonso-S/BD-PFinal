package modelo;

public class Equipo {

	    private int codigo;
	    private String nombreEquipo;
	    private String region;
	    private String locacion;
		public int getCodigo() {
			return codigo;
		}
		public void setCodigo(int codigo) {
			this.codigo = codigo;
		}
		public String getNombreEquipo() {
			return nombreEquipo;
		}
		public void setNombreEquipo(String nombreEquipo) {
			this.nombreEquipo = nombreEquipo;
		}
		public String getRegion() {
			return region;
		}
		public void setRegion(String region) {
			this.region = region;
		}
		public String getLocacion() {
			return locacion;
		}
		public void setLocacion(String locacion) {
			this.locacion = locacion;
		}




}
